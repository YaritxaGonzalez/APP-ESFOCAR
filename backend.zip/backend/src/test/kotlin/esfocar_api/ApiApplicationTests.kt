package esfocar_api

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
